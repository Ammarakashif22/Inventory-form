-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 24, 2023 at 08:35 AM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.2.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `inventory_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `brands`
--

CREATE TABLE `brands` (
  `id` int(11) NOT NULL,
  `brand_name` varchar(255) NOT NULL,
  `brand_date` date DEFAULT curdate()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `brands`
--

INSERT INTO `brands` (`id`, `brand_name`, `brand_date`) VALUES
(1, 'DELL', '2023-08-21'),
(2, 'DELL', '2023-08-21'),
(3, 'lenovo', '2023-08-22'),
(4, 'asdf', '2023-08-22');

-- --------------------------------------------------------

--
-- Table structure for table `inventory`
--

CREATE TABLE `inventory` (
  `id` int(11) NOT NULL,
  `location` varchar(20) NOT NULL,
  `department` varchar(20) NOT NULL,
  `section` varchar(20) NOT NULL,
  `emp_id` varchar(20) NOT NULL,
  `inventory_type` varchar(20) NOT NULL,
  `inventory_id` varchar(20) NOT NULL,
  `brand` varchar(20) NOT NULL,
  `model` varchar(20) NOT NULL,
  `specification` varchar(20) NOT NULL,
  `ram` varchar(20) NOT NULL,
  `ssd_hdd` varchar(20) NOT NULL,
  `service_tag` varchar(20) NOT NULL,
  `serial_number` varchar(20) NOT NULL,
  `condition_status` varchar(20) NOT NULL,
  `commissioning_date` date NOT NULL,
  `upgrading_date` date DEFAULT NULL,
  `handover_date` date DEFAULT NULL,
  `remarks` text DEFAULT NULL,
  `name` varchar(50) NOT NULL,
  `designation` varchar(50) NOT NULL,
  `institute` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `inventory`
--

INSERT INTO `inventory` (`id`, `location`, `department`, `section`, `emp_id`, `inventory_type`, `inventory_id`, `brand`, `model`, `specification`, `ram`, `ssd_hdd`, `service_tag`, `serial_number`, `condition_status`, `commissioning_date`, `upgrading_date`, `handover_date`, `remarks`, `name`, `designation`, `institute`) VALUES
(1, 'karachi', 'ddddddddddddd', 'cccccccccc', '77777777777', 'Switch', '322222', 'HP', 'ddddddddd', 'ffffffffffff', '2', '33333333333', '55555555555555', 'eee3333333', 'eeeeeeeeeeeeeee', '2023-09-08', '2023-09-02', '2023-08-18', 'sssssssssssssss', 'aaaaaaaaaaaaaaa', 'sssssssssssssss', 'cccccccccccccc'),
(2, 'karachi', 'asd', 'qwe', '1232', 'Mouse', '3233', 'lenovo', 'wewr', 'qwerty', '2', '344', '23424', '32435', 'sdfds', '2023-08-22', '2023-08-17', '2023-08-19', 'jhgfeyfg', 'zaid', 'abc', 'asd'),
(3, 'scdsfcd', 'dcscdf', 'dscfdsfc', '34545', 'Printer', '333333333333', 'DELL', '333333', 'e333333', '3', 'ee', 'eeee333', 'ee324', '4edde', '2023-09-04', '2023-08-23', '2023-08-12', 'eweede', 'aadscs', 'sdsdf', 'dsfcdf');

-- --------------------------------------------------------

--
-- Table structure for table `inventory_ids`
--

CREATE TABLE `inventory_ids` (
  `id` int(11) NOT NULL,
  `id_name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `inventory_types`
--

CREATE TABLE `inventory_types` (
  `id` int(11) NOT NULL,
  `type_name` varchar(255) NOT NULL,
  `type_date` date DEFAULT curdate()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `inventory_types`
--

INSERT INTO `inventory_types` (`id`, `type_name`, `type_date`) VALUES
(1, 'Printer', '2023-08-21'),
(2, 'Printer', '2023-08-21'),
(3, 'Printer', '2023-08-21'),
(4, 'Laptop', '2023-08-21'),
(5, 'Mouse', '2023-08-21'),
(6, '', '2023-08-22'),
(7, 'manage inventory', '2023-08-22'),
(8, 'new inventory', '2023-08-22'),
(9, 'USB', '2023-08-22');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `brands`
--
ALTER TABLE `brands`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `inventory`
--
ALTER TABLE `inventory`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `inventory_ids`
--
ALTER TABLE `inventory_ids`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `inventory_types`
--
ALTER TABLE `inventory_types`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `brands`
--
ALTER TABLE `brands`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `inventory`
--
ALTER TABLE `inventory`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `inventory_ids`
--
ALTER TABLE `inventory_ids`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `inventory_types`
--
ALTER TABLE `inventory_types`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
